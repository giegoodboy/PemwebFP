<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>

<!-- Mirrored from demo.w3layouts.com/demos_new/22-02-2017/employee_application_form-demo_Free/642256329/web/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Sep 2019 01:51:33 GMT -->
<!-- Added by HTTrack --><!-- <meta http-equiv="content-type" content="text/html;charset=UTF-8" /> --><!-- /Added by HTTrack -->
<head>
<title>open recruitment</title>
<link rel="icon" type="image/png" href="../images/logo-kolu.png" />
<!-- for-mobile-apps -->
<!-- <meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Employee Application Form Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" /> -->
<!-- <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script> -->
<!-- //for-mobile-apps -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style1.css">
<link rel="stylesheet" type="text/css" href="../css/all.css">
<!-- <link rel="stylesheet" href="css/jquery-ui.css" /> -->
<!-- <script src="js/jquery-1.12.0.min.js"></script> -->
<!-- <link href="css/stylesheet.css" rel="stylesheet"> -->
</head>

<!-- <script src='../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script> -->
<!-- <script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
  	}
})();
</script> -->
<!-- <script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script> -->
<!-- <script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
  	}
})();
</script> -->
<!-- <script type="text/javascript" src="http://services.bilsyndication.com/adv1/?d=353" defer="" async=""></script><script> var vitag = vitag || {};vitag.gdprShowConsentTool=false;vitag.outStreamConfig = {type: "slider", position: "left" };</script> -->

	<!-- Global site tag (gtag.js) - Google Analytics -->
<!-- <script async src="https://www.googletagmanager.com/gtag/js?id=UA-125810435-1"></script>
 --><!-- <script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-125810435-1');
</script> --><!-- <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../../../../../../www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-30027142-1', 'w3layouts.com');
  ga('send', 'pageview');
</script> -->
<body>
	<div class="main">
<!---728x90--->
<nav id="menunav" style="width: 100%">
    <input type="checkbox" id="checkbox1" />
    <label for="checkbox1">
<ul class="menu demo" style="width: 100%;">
  <li><a href="../index.html">Home</a></li>
  <li><a href="https://www.kolu.web.id/">Blog</a></li>  
  <li><a href="#">Pendaftaran</a></li>  
</ul>
  <span class="toggle"></span>
  </label>
</nav>

		<h1>Form open recruitment</h1>
<!---728x90--->

		<div class="w3_agile_main_grids">
			<div class="agileits_w3layouts_main_grid">
				
				

				<h1 style="color: black">MAAF PENDAFTARAN TELAH DITUTUP!!!!!!!!!!!!!!!!</h1>

			</div>
		</div>
<!---728x90--->

			<br>
			<br>
			<br>
		<div class="agileits_copyright">
			<p>2019 Open Recruitment | Design by <a href="#">Kolu</a></p>
		</div>
		<div class="agileits_copyright">

		</div>
	</div>
	<script src="js/filedrag.js"></script>
	<!-- start-date-piker-->
		<script src="js/jquery-ui.js"></script>
		<script>
			$(function() {
			$( "#datepicker" ).datepicker();
			});

		</script>
	<!-- //End-date-piker -->
</body>
<!-- Mirrored from demo.w3layouts.com/demos_new/22-02-2017/employee_application_form-demo_Free/642256329/web/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Sep 2019 01:51:42 GMT -->
</html>