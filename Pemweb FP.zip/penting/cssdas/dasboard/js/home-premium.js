$(function(){Messenger.options={extraClasses:"messenger-fixed messenger-on-top  messenger-on-right",
	theme:"flat",messageDefaults:{showCloseButton:!0}}});


// $(function(){Messenger.options={extraClasses:"messenger-fixed messenger-on-top  messenger-on-right",
// 	theme:"flat",messageDefaults:{showCloseButton:!0}},Messenger().post({message:"Haloo, Selamat Datang Di Sistem Pendaftaran KOLU",type:"success"})});